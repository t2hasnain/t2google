# Goggl - The Most Unique Search Engine in the World

![Goggl](https://i.ibb.co/yQdYhtq/image.png)

## Introduction
This is a code repository for the corresponding video tutorial. 

In this video, we will create a Google Clone app. We're going to use React and Goole Search API powered by https://rapidapi.com.

By the end of this video, you will become the master of working with APIs.

Setup:
- run ```npm i && npm start``` to start the development server

## Stay up to date with new projects
New major projects coming soon, subscribe to the mailing list to stay up to date https://resource.jsmasterypro.com/newsletter
